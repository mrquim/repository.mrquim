import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/inspirationlinks/inspiration/novo-adoon/plugin.video.inspiration'
addon = xbmcaddon.Addon('plugin.video.inspiration')