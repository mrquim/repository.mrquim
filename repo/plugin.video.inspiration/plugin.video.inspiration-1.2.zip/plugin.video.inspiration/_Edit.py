import xbmcaddon
import base64

MainBase = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0pOMTk3NC9lbmZpbS9tYXN0ZXIvQWRkb25fcGx1Z2lu'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.inspiration')