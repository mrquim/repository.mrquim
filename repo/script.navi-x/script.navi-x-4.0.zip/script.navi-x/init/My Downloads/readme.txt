Store your downloaded files in this folder. You can browse
these files from the "My Downloads" section in Navi-X.

Enjoy.
