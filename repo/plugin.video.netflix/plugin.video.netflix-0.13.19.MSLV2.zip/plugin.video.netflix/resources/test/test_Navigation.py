# -*- coding: utf-8 -*-
# Module: Navigation
# Author: asciidisco
# Created on: 11.10.2017
# License: MIT https://goo.gl/5bMj3H

"""Tests for the `Navigation` module"""

import unittest
import mock
from resources.lib.Navigation import Navigation

class NavigationTestCase(unittest.TestCase):
    pass
