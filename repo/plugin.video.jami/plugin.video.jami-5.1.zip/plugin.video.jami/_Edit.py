import xbmcaddon
import base64

MainBase = 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvcnFCZXpLNXI='.decode('base64')
addon = xbmcaddon.Addon('plugin.video.jami')